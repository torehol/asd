﻿using Azets.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Azets
{
    public class ProcessedOrder
    {
        public int OrderId { get; set; }
        public DateTime TimeOfOrder { get; set; }
        public int ClientID { get; set; }
        public List<Item> Items { get; set; }
        public bool Valid { get; set; }
        public double Price { get; set; }
    }
}
