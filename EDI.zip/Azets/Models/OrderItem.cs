﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Azets.Models
{
    public class OrderItem
    {
        public int ProductId { get; set; }
    }
}
