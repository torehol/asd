﻿using Azets.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Azets
{
    public class Order
    {
        public DateTime TimeOfOrder { get; set; }
        public int ClientID { get; set; }
        public List<int> Items {get; set;}
    }
}
