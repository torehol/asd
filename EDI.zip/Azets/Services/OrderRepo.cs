﻿using Azets.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Azets.Services
{
    public class OrderRepo : IOrderRepo
    {
        public Item GetProduct(int orderId)
        {
            var item = new Item
            {
                Id = 1,
                Name = "A real product"
            };
            return item;
        }

        public int GenerateId()
        {
            //Should be handled by db           
            return 1;
        }

        public bool AddOrder(ProcessedOrder order)
        {
            //Adds new order to DB
            return true;
        }
        public bool Save()
        {
            ///Saves any changes made to DB
            return true;
        }
    }
}
