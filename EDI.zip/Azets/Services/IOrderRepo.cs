﻿using Azets.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Azets.Services
{
    public interface IOrderRepo
    {
        Item GetProduct(int orderId);
        int GenerateId();
        bool AddOrder(ProcessedOrder order);
        bool Save();
    }
}
