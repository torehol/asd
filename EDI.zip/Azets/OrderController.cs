﻿using Azets.Models;
using Azets.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Azets
{
    [Route("api/orders")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        public IOrderRepo _repo;
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "Api", "Here" };
        }
        //Post api/orders
        [HttpPost]
        public IActionResult PlaceOrder([FromBody] Order order)
        {
            if (order == null)
            {
                return BadRequest();
            }
            /// Validate message content
            /// 

            var returnOrder = new ProcessedOrder
            {
                OrderId = _repo.GenerateId(),
                TimeOfOrder = DateTime.Now.Date,
                ClientID = order.ClientID
            };
            double price = 0;
            var productList = new List<Item>();
            foreach (var itemId in order.Items)
            {
                var product = _repo.GetProduct(itemId);
                if (ModelState.IsValid)
                {
                    price = price + product.Price;
                    productList.Add(product);
                }
            }
            returnOrder.Items = productList;
            returnOrder.Price = price;
            _repo.AddOrder(returnOrder);

            if (!_repo.Save())
            {
                return StatusCode(500, "An error occured");                
            }            
            return CreatedAtRoute("GetOrder", new { id = returnOrder.OrderId }, returnOrder);
        }
    }
}
